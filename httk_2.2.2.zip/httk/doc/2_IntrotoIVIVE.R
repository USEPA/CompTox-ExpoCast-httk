## ----install_httk, eval = FALSE-----------------------------------------------
#  install.packages("httk")

## ----install_readxl, eval = FALSE---------------------------------------------
#  install.packages("readxl")

## ----setup_vignette, eval = TRUE----------------------------------------------
knitr::opts_chunk$set(echo = TRUE, fig.width=5, fig.height=4)

## ----clear_memory, eval = TRUE------------------------------------------------
rm(list=ls())

## ----load_packages, eval = TRUE-----------------------------------------------
library(httk)
library(readxl)

## ----load_hts, eval = FALSE---------------------------------------------------
#  toxcast <- read.csv("ac50_Matrix_190708.csv",stringsAsFactors=F)

## ----load_mychems, eval = FALSE-----------------------------------------------
#  mychems <- read.xls("mychems.xls",stringsAsFactors=F)

## ----calc_equivalent_dose1, eval = FALSE--------------------------------------
#  head(mychems)

## ----calc_equivalent_dose2, eval = FALSE--------------------------------------
#  my.tox <- subset(toxcast,CAS%in%mychems$CASRN)

## ----calc_equivalent_dose3, eval = FALSE--------------------------------------
#  dim(my.tox)

## ----calc_equivalent_dose4, eval = FALSE--------------------------------------
#  dim(mychems)

## ----calc_equivalent_dose5, eval = FALSE--------------------------------------
#  toxcast.start <- 2
#  toxcast.end <- 1474

## ----calc_equivalent_dose6, eval = FALSE--------------------------------------
#  my.tox$tenth <- apply(my.tox[,toxcast.start:toxcast.end],
#                    1,
#                    function(x) quantile(x,0.1,na.rm=T))

## ----calc_equivalent_dose7, eval = FALSE--------------------------------------
#  my.tox <- subset(my.tox,tenth<1e6)

## ----calc_equivalent_dose8, eval = FALSE--------------------------------------
#  my.tox <- my.tox[,c("CAS","tenth")]

## ----calc_equivalent_dose9, eval = FALSE--------------------------------------
#  my.tox <- merge(my.tox,mychems,by.x="CAS",by.y="CASRN")

## ----calc_equivalent_dose10, eval = FALSE-------------------------------------
#  library(httk)

## ----calc_equivalent_dose11, eval = FALSE-------------------------------------
#  for (this.cas in my.tox$CAS)
#  {
#  # get_cheminfo() gives a list of all the CAS numbers for which HTTK will work:
#    if (this.cas %in% get_cheminfo())
#    {
#  # Set a random number generator seed so that the Monte Carlo will always give
#  # the same random sequence:
#      set.seed(12345)
#  # calc_mc_css gives us the predicted plasma concentration for a 1 mg/kg/day
#  # dose at steady-state:
#      my.tox[my.tox$CAS==this.cas,"Css"] <-
#        calc_mc_css(chem.cas=this.cas,output.units="uM")
#      my.tox[my.tox$CAS==this.cas,"Css.Type"] <- "in vitro"
#    }
#  }

## ----calc_equivalent_dose12, eval = FALSE-------------------------------------
#  my.tox[,c("PREFERRED_NAME","tenth","Css","Css.Type")]

## ----load_qspr, eval = FALSE--------------------------------------------------
#  load_sipes2017()

## ----calc_equivalent_dose13, eval = FALSE-------------------------------------
#  for (this.cas in my.tox$CAS)
#  {
#  # But only calculate if we didn't already have a value (NOTE: load_sipes2017
#  # will not overwrite the in vitro data by default, so you'll still get the same
#  # answer if you use the same random number seed, but you would also be wasting
#  # time):
#    if (this.cas %in% get_cheminfo() &
#      is.na(my.tox[my.tox$CAS==this.cas,"Css"]))
#    {
#      set.seed(12345)
#  # This gives us the predicted plasma concentration for a 1 mg/kg/day dose at
#  # steady-state:
#      my.tox[my.tox$CAS==this.cas,"Css"] <-
#        calc_mc_css(chem.cas=this.cas,output.units="uM")
#      my.tox[my.tox$CAS==this.cas,"Css.Type"] <- "in silico"
#    }
#  }

## ----calc_equivalent_dose14, eval = FALSE-------------------------------------
#  my.tox[,c("PREFERRED_NAME","tenth","Css","Css.Type")]

## ----calc_equivalent_dose15, eval = FALSE-------------------------------------
#  par(mar = c(3, 2, 2,2))
#  plot(x=1:14,
#       y=my.tox$BER,
#       log="y",
#       xaxt="n",
#       xlab="")
#  axis(1, at=1:14,
#       labels=substr(my.tox$PREFERRED_NAME,1,10),las=2)

## ----calc_equivalent_dose16, eval = FALSE-------------------------------------
#  my.tox$EquivDose <- my.tox$tenth / my.tox$Css

## ----display_table2, eval = FALSE---------------------------------------------
#  my.tox[,c("PREFERRED_NAME","tenth","EquivDose")]

## ----load_seem3, eval = FALSE-------------------------------------------------
#  SEEM3 <- read.csv("SupTable-all.chem.preds-2018-11-28.txt",stringsAsFactors=F)

## ----mergetoxexposure, eval = FALSE-------------------------------------------
#  my.tox <- merge(my.tox,SEEM3[,c("CAS","seem3","seem3.l95","seem3.u95","Pathway","AD")])

## ----calc_ber, eval = FALSE---------------------------------------------------
#  my.tox$BER <- my.tox$EquivDose/my.tox$seem3.u95

## ----sort_by_ber, eval = FALSE------------------------------------------------
#  my.tox <- my.tox[order(my.tox$BER),]

## ----ber_plot_margins, eval = FALSE-------------------------------------------
#  par(mar = c(7, 5, 4,2))

## ----ber_plot, eval = FALSE---------------------------------------------------
#  plot(x=factor(my.tox$PREFERRED_NAME,levels=my.tox$PREFERRED_NAME),
#       y=my.tox$BER,
#  # Use a log scale on the y-axis:
#       log="y",
#       xaxt="n",
#       xlab="",
#       ylab="Bioactivity:Exposure Ratio",
#       cex.lab=1.5)
#  # Plot the first 15 characters of each chemical name on the horizontal eaxis:
#  axis(1, at=factor(my.tox$PREFERRED_NAME,levels=my.tox$PREFERRED_NAME),
#       labels=substr(my.tox$PREFERRED_NAME,1,15),las=2)

