#' Parameterize_gas_pbtk
#' 
#' This function initializes the parameters needed in the function solve_gas_pbtk
#' 
#' 
#' @param chem.name Either the chemical name or the CAS number must be
#' specified. 
#' @param chem.cas Either the chemical name or the CAS number must be
#' specified. 
#' @param dtxsid EPA's DSSTox Structure ID (\url{https://comptox.epa.gov/dashboard})   
#' the chemical must be identified by either CAS, name, or DTXSIDs
#' @param species Species desired (either "Rat", "Rabbit", "Dog", "Mouse", or
#' default "Human").
#' @param default.to.human Substitutes missing animal values with human values
#' if true (hepatic intrinsic clearance or fraction of unbound plasma).
#' @param tissuelist Specifies compartment names and tissues groupings.
#' Remaining tissues in tissue.data are lumped in the rest of the body.
#' However, solve_pbtk only works with the default parameters.
#' @param force.human.clint.fup Forces use of human values for hepatic
#' intrinsic clearance and fraction of unbound plasma if true.
#' @param clint.pvalue.threshold Hepatic clearance for chemicals where the in
#' vitro clearance assay result has a p-values greater than the threshold are
#' set to zero.
#' @param adjusted.Funbound.plasma Returns adjusted Funbound.plasma when set to
#' TRUE along with parition coefficients calculated with this value.
#' @param regression Whether or not to use the regressions in calculating
#' partition coefficients.
#' @param suppress.messages Whether or not the output message is suppressed.
#' @param minimum.Funbound.plasma Monte Carlo draws less than this value are set 
#' equal to this value (default is 0.0001 -- half the lowest measured Fup in our
#' dataset).
#' @param vmax Michaelis-Menten vmax value in reactions/min
#' @param km Michaelis-Menten concentration of half-maximal reaction velocity
#' in desired output concentration units. 
#' @param exercise Logical indicator of whether to simulate an exercise-induced
#' heightened respiration rate
#' @param fR Respiratory frequency (breaths/minute), used especially to adjust
#' breathing rate in the case of exercise. This parameter, along with VT and VD
#' (below) gives another option for calculating Qalv (Alveolar ventilation) 
#' in case pulmonary ventilation rate is not known 
#' @param VT Tidal volume (L), to be modulated especially as part of simulating
#' the state of exercise
#' @param VD Anatomical dead space (L), to be modulated especially as part of
#' simulating the state of exercise
#' @param ... Other parameters
#' 
#' @return \item{BW}{Body Weight, kg.} 
#' \item{Clint}{Hepatic intrinsic clearance, uL/min/10^6 cells}
#' \item{Clint.dist}{Distribution of hepatic intrinsic clearance values
#' (median, lower 95th, upper 95th, p value)} 
#' \item{Clmetabolismc}{Hepatic Clearance, L/h/kg BW.} 
#' \item{Fgutabs}{Fraction of the oral dose absorbed, i.e. the fraction of the
#' dose that enters the gut lumen.}
#' \item{Fhep.assay.correction}{The fraction of chemical unbound in hepatocyte
#' assay using the method of Kilford et al. (2008)} 
#' \item{Funbound.plasma}{Fraction of chemical unbound to plasma.} 
#' \item{Funbound.plasma.adjustment}{Fraction unbound to plasma adjusted as
#' described in Pearce et al. 2017}
#' \item{Funbound.plasma.dist}{Distribution of fraction unbound to plasma
#' (median, lower 95th, upper 95th)}
#' \item{hematocrit}{Percent volume of red blood cells in the blood.}
#' \item{Kblood2air}{Ratio of concentration of chemical in blood to air}
#' \item{Kgut2pu}{Ratio of concentration of chemical in gut tissue to unbound
#' concentration in plasma.} 
#' \item{kgutabs}{Rate that chemical enters the gut from gutlumen, 1/h.} 
#' \item{Kkidney2pu}{Ratio of concentration of chemical in kidney tissue to
#' unbound concentration in plasma.} 
#' \item{Kliver2pu}{Ratio of concentration of chemical in liver tissue to
#' unbound concentration in plasma.} 
#' \item{Klung2pu}{Ratio of concentration of chemical in lung tissue
#' to unbound concentration in plasma.} 
#' \item{km}{Michaelis-Menten concentration of half-maximal activity}
#' \item{Kmuc2air}{Mucus to air partition coefficient}
#' \item{Krbc2pu}{Ratio of concentration of chemical in red blood cells to
#' unbound concentration in plasma.}
#' \item{Krest2pu}{Ratio of concentration of chemical in rest of body tissue to
#' unbound concentration in plasma.} 
#' \item{kUrtc}{Unscaled upper respiratory tract uptake parameter (L/h/kg^0.75)}
#' \item{liver.density}{Density of liver in g/mL}
#' \item{MA}{phospholipid:water distribution coefficient, membrane affinity}
#' \item{million.cells.per.gliver}{Millions cells per gram of liver tissue.} 
#' \item{MW}{Molecular Weight, g/mol.}
#' \item{pKa_Accept}{compound H association equilibrium constant(s)}
#' \item{pKa_Donor}{compound H dissociation equilibirum constant(s)}
#' \item{Pow}{octanol:water partition coefficient (not log transformed)}
#' \item{Qalvc}{Unscaled alveolar ventilation rate (L/h/kg^0.75)}
#' \item{Qcardiacc}{Cardiac Output, L/h/kg BW^3/4.} 
#' \item{Qgfrc}{Glomerular Filtration Rate, L/h/kg BW^0.75, volume of fluid
#' filtered from kidney and excreted.} 
#' \item{Qgutf}{Fraction of cardiac output flowing to the gut.}
#' \item{Qkidneyf}{Fraction of cardiac output flowing to the kidneys.}
#' \item{Qliverf}{Fraction of cardiac output flowing to the liver.}
#' \item{Qlungf}{Fraction of cardiac output flowing to lung tissue.}
#' \item{Qrestf}{Fraction of blood flow to rest of body}
#' \item{Rblood2plasma}{The ratio of the concentration of the chemical in the
#' blood to the concentration in the plasma from available_rblood2plasma.}
#' \item{Vartc}{Volume of the arteries per kg body weight, L/kg BW.}
#' \item{Vgutc}{Volume of the gut per kg body weight, L/kg BW.}
#' \item{Vkidneyc}{Volume of the kidneys per kg body weight, L/kg BW.}
#' \item{Vliverc}{Volume of the liver per kg body weight, L/kg BW.}
#' \item{Vlungc}{Volume of the lungs per kg body weight, L/kg BW.}
#' \item{vmax}{Michaelis-Menten maximum reaction velocity (1/min)}
#' \item{Vmucc}{Unscaled mucosal volume (L/kg BW^0.75}
#' \item{Vrestc}{ Volume of the rest of the body per kg body weight, L/kg BW.}
#' \item{Vvenc}{Volume of the veins per kg body weight, L/kg BW.} 
#'
#' @author Matt Linakis, Robert Pearce, John Wambaugh
#'
#' @references 
#' Linakis, Matthew W., et al. "Development and Evaluation of a High Throughput 
#' Inhalation Model for Organic Chemicals", submitted
#'
#' Kilford, P. J., Gertz, M., Houston, J. B. and Galetin, A.
#' (2008). Hepatocellular binding of drugs: correction for unbound fraction in
#' hepatocyte incubations using microsomal binding or drug lipophilicity data.
#' Drug Metabolism and Disposition 36(7), 1194-7, 10.1124/dmd.108.020834.
#'
#' @keywords Parameter
#'
#' @examples
#' parameters <- parameterize_gas_pbtk(chem.cas='129-00-0')
#' 
#' parameters <- parameterize_gas_pbtk(chem.name='pyrene',species='Rat')
#' 
#' parameterize_gas_pbtk(chem.cas = '56-23-5')
#' 
#' parameters <- parameterize_gas_pbtk(chem.name='Carbon tetrachloride',species='Rat')
#' 
#' # Change the tissue lumping:
#' compartments <- list(liver=c("liver"),fast=c("heart","brain","muscle","kidney"),
#'                       lung=c("lung"),gut=c("gut"),slow=c("bone"))
#' parameterize_gas_pbtk(chem.name="Bisphenol a",species="Rat",default.to.human=TRUE,
#'                    tissuelist=compartments) 
#' 
#' @export parameterize_gas_pbtk
parameterize_gas_pbtk <- function(chem.cas=NULL,
                              chem.name=NULL,
                              dtxsid=NULL,
                              species="Human",
                              default.to.human=F,
                              tissuelist=list(
                                liver=c("liver"),
                                kidney=c("kidney"),
                                lung=c("lung"),
                                gut=c("gut")),
                              force.human.clint.fup = F,
                              clint.pvalue.threshold=0.05,
                              adjusted.Funbound.plasma=T,
                              regression=T,
                              vmax = 0,
                              km = 1,
                              exercise = F,
                              fR = 12,
                              VT = 0.75,
                              VD = 0.15,
                              suppress.messages=F,
                              minimum.Funbound.plasma=0.0001,
                              ...)
{
  physiology.data <- physiology.data

# We need to describe the chemical to be simulated one way or another:
  if (is.null(chem.cas) & 
    is.null(chem.name) & 
    is.null(dtxsid)) 
    stop('chem.name, chem.cas, or dtxsid must be specified.')

# Look up the chemical name/CAS, depending on what was provide:
  out <- get_chem_id(
    chem.cas=chem.cas,
    chem.name=chem.name,
    dtxsid=dtxsid)
  chem.cas <- out$chem.cas
  chem.name <- out$chem.name                                
  dtxsid <- out$dtxsid
   
  if (class(tissuelist)!='list') stop("tissuelist must be a list of vectors.") 
  # Clint has units of uL/min/10^6 cells
  Clint.db <- try(get_invitroPK_param("Clint",species,chem.cas=chem.cas),silent=T)
  # Check that the trend in the CLint assay was significant:
  Clint.pValue <- try(get_invitroPK_param("Clint.pValue",species,chem.cas=chem.cas),silent=T)
  if ((class(Clint.db) == "try.null(ch/.ram(h/.ram,                P             chem.name=NULL,
                              dtxsid=NULL,
             us=chem.cas),silvidrameterize_gas.human=Fb) == "try.null(ch/.ram(h/.ram,pValue",species,chem.cas=chem.cas),silent=T)
  if ((class.human=Fb) == "try.null(ch/.ram(h/.ram,pV    !  minimum.Funboun)y.data httkpop(pompa((Clint.d"ther sy or human imagedmd.10895th, p valu194-7 a",  }t must be a l     P             chem.be specified"M (hepatedmd.10895th, p valu194-argume"kiint when restres with human valu_rblrtem{kgss
#' if tand fraction7 asignificantusttable (reaot starwest re(ch\item{million,tusth\item{million,toefficierit}{Pe) & 
  n Corl     P    - n Corlgss
(ss.,"",     P   )==3id=NULL,
         10^6,ch     P  L,
       ,char dterize(em{splitl     P  s.,")[[1]][1]ram,pValue",species,char dterize(em{splitl     P  s.,")[[1]][4]ram,pV    !  minimum.Funboun) httkpop(T)
  i (recalculatiet to default case asig} eleffLL,
       6,ch     P  L,
         10^6,chNA,  }t must !or da(alue",speciehem.alue",species>           adjusted.Fun)      66,ch0

AS, . 
  ThficiePC of un

Cthe body.
#'c("liver"nt formattie) &, 2020)his hashloride',species, 2020)(txsid=dtxsid)
  chem.caaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaafault.to(Clint.dem.caaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa tissuelist=list( tissuelist=listdem.caaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaand neutral lip=                 dtxshem.caaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaf minimum.FunboundThem.caaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa             ...)
{
  ph             ...)
{
  pasigPC ohlorn 2.0.1 (February 28, 2020)e models (to( 2020)his hahem.caaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaafault.to(Clint.dem.caaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa         regression=T,
           regression=T,
 dem.caaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa= 0,
      = 0,
     hem.caaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaf minimum.Funboundf minimum.Funbounhem.caaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa             ...)
{
  ph             ...)
{
  pas# G(fx pbtk _the bodyrUE alongn/10^6n.clint.f_pbtk oPC retedific ca
impoe) & pbtk _his hashlo pbt_the bod(PC rliver=c("liliver=c("l,fault.to(Clint.)
AS, .ficant:oas chustwdephin sooefficiePirovano ose cnvitrincubation:ist must d in Sipes et al. (2017) =NULL,
  ose hlo( 2020)his ha$s et al. (2017)am,pV    !  minimum.Funboun) httkpop(
'value are set 
#' \item{Ffop Monovano e difference (is, Mattet alrestred.plasma when set to
#' T  Correctn coefforiginntrinsicn whig} eleffose hlo( 2020)his ha$und.plasma when set to
#' hat Rro dataas selecteemicalse) & 
  ose ha             ...)
{
  p)fose hlo             ...)
{
  p

AS the frs,chem.cas=chem.cas),silent=T the frss(Clint.db) == "try.null(ch/.ram(h/.ram,    be a lwere unu          chem.be the frs,ch1
AS,gnificant:
ument "infng zwitten casepffelf fup aecal.namtissue (regression) aup any.
#'c("lattieist must !((Clint. %in%a",  in t(al to be simula)) =NULL,
  ust to0.75)((Clint.) %in%ato0.75)(",  in t(al to be simula)) =NUNULL,
  o desc.(Clint. ,ch",  in t(al to be simula)[to0.75)(",  in t(al to be simula))==to0.75)((Clint.)]L,
  } eleffifiedpompa("Ponal Health aPKu194-arguss(Clint.d"n) af ...) a",  } eleffdesc.(Clint. ,ch(Clint.hat waamodel
  U
  To decrease packags, andipecies is,  me ofdesc.e chemical to be simula[,desc.(Clint.]L,
 in t(me ofdesc.e ch)emical to be simula[,1]
AS,glesame=chers of CAS and/d"MW=Fb) == "try.null(ch #on eqated bant(s) ,ch( minimuW2019)
(=chers of CAS and/d"d bant(s)=Fb) == "try.null(chh # acst'w}{octanol:wan coeffisated bant(s)} ,ch( minimuW2019)
(=chers of CAS and/d"d bant(s)}=Fb) == "try.null(chh # bar 95a{octanol:wan sneffisatePows,ch10^=chers of CAS and/d"repl=Fb) == "try.null(ch # Oformed)}
#' \item{Qalvc}{Unscealed 
 chem.l10^6,chver") =NUN# Begina
impoe) &#mparam(kgBW calc_analytickidneyBWe) &QGFRcs,chee ofdesc.e ch["GFR"]("C00*60S,gltem{Qgfrc =hee ofdesc.e ch["Glomerular Fil"]("C00*60S,gl
impos,chuncle","pbtk _his ha[ss
#'r( in t("pbtk _his ha),1,1u    'Q']ra chem.l10^6,chc(em.l10^,c
    dtem{Qgfrc =har dterize(tem{Qgfrct.fup =
impo[! in t(
impo) %in%ac('Qramet. liver')], #MWLverwrite 'g tiss', 9/19/19    dt liver==
impo[['Qramet. liver']] - 
impo[['Qut.}']].fup =, vol =har dterize(tGFRc))nt.db <e ca
impoAS,gl
UN# Begina the rs
UN# invitrphin sobearce,BW l
UN L/kg =hee ofdesc.e ch["Po
#' T 
#'
#"]((1-ee ofdesc.e ch["Hhe blood."])/2("C00 #rce,BW
UN g BW =hee ofdesc.e ch["Po
#' T 
#'
#"]((1-ee ofdesc.e ch["Hhe blood."])/2("C00 #rce,BW
 chem.l10^6,chc(em.l10^,fup = L/kg =har dterize( L/kgt.fup = g BW =har dterize( g BWt.fup ="pbtk _his ha[ss
#'r( in t("pbtk _his ha),1,1u    'V'].fup ="pbtk _his ha[ss
#'r( in t("pbtk _his ha),1,1u    'K']ram,
AS, .f@para{Vlungc0^6 ceease packae) &BWs,chee ofdesc.e ch["Ailitge&BW"]r to mounts in=hee ofdesc.e ch["Hhe blood."] chem.l10^6,chc(em.l10^,cle",BWs=har dterize(BWt.fup =rsion 1.=

  , #on oe specwhen set to
#' T=fose,N# invilue (somal bi specwhen set to
#'   10^6=o( 2020)his ha$s et al. (2017)  10^.fup =o mounts in=har dterize(o mounts i),N# invilue (.}
#'fup =MWs=hMW, #on eqatetePows=ePow.fup =d bant(s)=d bant(s).fup =d bant(s)}=d bant(s)}.fup =MAo( 2020)his ha[["MA"]].fup =ramet    1.0, # RblooMWLv9-20-19    d\itemessagiolohh # RblooMWLv9-20-19   signifs causi using microsomal binconcentration iVlunr drug lipophif true.
#' @param nvitr({Fraction of cttet08) chem.l10^6,chc(em.l10^,cle", specwbound in hepatocyte
=ty
  Fixfu),
     ease packag=hver")Pows=e( 2020)his ha$Pow.fup = =d bant(s)=( 2020)his ha$d bant(s).fup = =d bant(s)}=( 2020)his ha$d bant(s)}.fup =aaf minimum.Funboundf minimum.Funboun)))ntgnisomal bin
t must     ==0 =NULL,
  ust !  minimum.Funboun) y.data httkpop("Glnll)
ng a tissses flogy.item{Fgutaor calc       e fup.mea blood t tim-ctieagedmd.10895th, p vale asigchem.l10^6,chc(em.l10^, ver"),
         =         km=1, #kmelecteemic1 (reaodummyelectee p-v            =     ,               10^6=o       10^,         item{Fgutabn=har dterize(ty
  Fixed output),
       d <- out$d= hem.cas
  chem.up =o the mo nami="uestc}{ =F,
        models (tover"),
              =     , #_param("Clint",speciiiiiiiii     ...)
{
  phose,N# invilue (somal bi specm.up =o tnd in hepatocyte
=em.l10^$wbound in hepatocyte
,        aaaa  f liver tissue.} 
#' \   10, #onClint",sp/g-
#' \
           kidnphosphol   und. #on co
          Dn=0.17,BW=BWhem.caaaaaaaL/kg BW="pbtk _his ha$L/kg BW, #rce,em.caaaaaaaQramet. livec=("pbtk _his ha$Qramet. livec)("C00*60t.fup = F,
f minimum.FunboundT)), #rcdney an
  aaaa  f liver tissue.} 
#' \  10, #onClint",sp/g-
#' \
       kidnphosphol  und. #on co
       the fr=were unu) #rcdney an
  } eleffLL,
  em.l10^6,chc(em.l10^,cle", spec      =    ,km=km,            =     ,               10^6=o       10^,          item{Fgutab=   
  if (class(tissuelist)!aaaa  f liver tissue.} 
#' \  10, #onClint",sp/g-
#' \
       kidnphosphol  und. #on co
       the fr=were unu)#MLm.physiK,
  kme9-19-19   }
 
 
 ust d in Sipes et al. (2017) d=NULL,
  em.l10^["lasma adjusted as
#' descr"] hlo( 2020)his ha$s et al. (2017)as
#' descr
  } eleffem.l10^["lasma adjusted as
#' descr"] hloNA,   L,
  em.l10^6,chc(em.l10^,
      the chemical =of the arteries per kg (txsid=dtxsid)
  chem.caaaaafault.to(Clint.dem.caaaaa         regression=T,
           regression=T,
 dem.caaaaaf minimum.FunboundT))
elist)!aa#{Qcardiacc}{Cardiac : 15ckidney^.75ed for pmpbded Funbt)!aa#henry's lad Piratm * m^3 /  eq, calc_analyatm od Pat)!aa#hure fr} 
#' values formic310 Kelvii specrepHenry
  =chers of CAS and/dW}{Bod  'repHenry', b) == "try.null(ch # usiar vord a10 tk
pi}{ VHenry's lad e)} 
#'up =ols,ch10^repHenry
#Henry's n coeffi Piratm*m^3 /  eqst)!aa#Gas n coeffi 8.314 PirinvitroPKJ/( eq*K),fr} 
#' values fort)!aar} 
_' van=har dterize(ee ofdesc.e ch['Ailitge&B} 
#T values fo']r + 273.15c#C -> Kt)!aaK}
#' m{Krs,ch8.314 *ar} 
_' van/ (ols*h101325 CAS#101325yatm od Part)!aa blood to s,chK}
#' m{Krs* em.l10^$.

Changes i/ em.l10^$s et al. (2017)am,pVlK{Kr2ite6,chvog10(1/K}
#' m{Kr  - (vog10(Pveolch1)s* 0.524 #If det Shyam Pa load imagrepl, it's pKa data\item{Krn=hK}
#' m{Krt)!aa {Kr2ite6,ch10^(lK{Kr2ite)
elis\item{Krn,ch1/K{Kr2iteL,
  us(12,
    )LL,
  o ^0.75n=h((fR*60ts* (VTlchVD))/em.l10^$the bod #rcdneyd excreL,
  o # Rbloo4-30-19ration as an o-ers ne
#' \item{li  
Char fore)} 
#dem.caaa#pKa dasters neinvitroPKLity anin^-1L,
  } eleffLL,
  o Vdots,chee ofdesc.e ch["P VT TidalV}{Cardiac O fro"]L,
  o ^0.75n,chVdots* (0.67) #rcdneyd excL,
  }L,
  em.l10^6,chc(em.l10^, blood to s=aa blood to ,\item{Krn=hKitem{Kr,^0.75=ar dterize(t0.75))
elist)!aaelist)!rUE al(lapply(em.l