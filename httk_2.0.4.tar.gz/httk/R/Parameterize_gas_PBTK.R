#' Parameterize_gas_pbtk
#' 
#' This function initializes the parameters needed in the function solve_gas_pbtk
#' 
#' 
#' @param chem.name Either the chemical name or the CAS number must be
#' specified. 
#' @param chem.cas Either the chemical name or the CAS number must be
#' specified. 
#' @param dtxsid EPA's DSSTox Structure ID (\url{https://comptox.epa.gov/dashboard})   
#' the chemical must be identified by either CAS, name, or DTXSIDs
#' @param species Species desired (either "Rat", "Rabbit", "Dog", "Mouse", or
#' default "Human").
#' @param default.to.human Substitutes missing animal values with human values
#' if true (hepatic intrinsic clearance or fraction of unbound plasma).
#' @param tissuelist Specifies compartment names and tissues groupings.
#' Remaining tissues in tissue.data are lumped in the rest of the body.
#' However, solve_pbtk only works with the default parameters.
#' @param force.human.clint.fup Forces use of human values for hepatic
#' intrinsic clearance and fraction of unbound plasma if true.
#' @param clint.pvalue.threshold Hepatic clearance for chemicals where the in
#' vitro clearance assay result has a p-values greater than the threshold are
#' set to zero.
#' @param adjusted.Funbound.plasma Returns adjusted Funbound.plasma when set to
#' TRUE along with parition coefficients calculated with this value.
#' @param regression Whether or not to use the regressions in calculating
#' partition coefficients.
#' @param suppress.messages Whether or not the output message is suppressed.
#' @param minimum.Funbound.plasma Monte Carlo draws less than this value are set 
#' equal to this value (default is 0.0001 -- half the lowest measured Fup in our
#' dataset).
#' @param vmax Michaelis-Menten vmax value in reactions/min
#' @param km Michaelis-Menten concentration of half-maximal reaction velocity
#' in desired output concentration units. 
#' @param exercise Logical indicator of whether to simulate an exercise-induced
#' heightened respiration rate
#' @param fR Respiratory frequency (breaths/minute), used especially to adjust
#' breathing rate in the case of exercise. This parameter, along with VT and VD
#' (below) gives another option for calculating Qalv (Alveolar ventilation) 
#' in case pulmonary ventilation rate is not known 
#' @param VT Tidal volume (L), to be modulated especially as part of simulating
#' the state of exercise
#' @param VD Anatomical dead space (L), to be modulated especially as part of
#' simulating the state of exercise
#' @param ... Other parameters
#' 
#' @return \item{BW}{Body Weight, kg.} 
#' \item{Clint}{Hepatic intrinsic clearance, uL/min/10^6 cells}
#' \item{Clint.dist}{Distribution of hepatic intrinsic clearance values
#' (median, lower 95th, upper 95th, p value)} 
#' \item{Clmetabolismc}{Hepatic Clearance, L/h/kg BW.} 
#' \item{Fgutabs}{Fraction of the oral dose absorbed, i.e. the fraction of the
#' dose that enters the gut lumen.}
#' \item{Fhep.assay.correction}{The fraction of chemical unbound in hepatocyte
#' assay using the method of Kilford et al. (2008)} 
#' \item{Funbound.plasma}{Fraction of chemical unbound to plasma.} 
#' \item{Funbound.plasma.adjustment}{Fraction unbound to plasma adjusted as
#' described in Pearce et al. 2017}
#' \item{Funbound.plasma.dist}{Distribution of fraction unbound to plasma
#' (median, lower 95th, upper 95th)}
#' \item{hematocrit}{Percent volume of red blood cs}
eight, kg.} 
#' \item{Clint}{Hepatic intrinsic clearance, uL/min/10^s used in pKhangesair}{R), tlasmadesired output con unbound insic cThisir}s used in pKion2pu}{R), tlasmadesired output con unbound iion  Correceffi
#' \s useadesired outpu.only=TRUound to plasmakraction RaV than 0on unboun}{The fraction 2015)ionof ch, 1/hound to plasmaKport(l2pu}{R), tlasmadesired output con unbound iport(l  Correcefd to }
#' \iadesired outpu.only=TRUound to plasmaKload_2pu}{R), tlasmadesired output con unbound iload_  Correcefd to }
#' \iadesired outpu.only=TRUound to plasmaKlung2pu}{R), tlasmadesired output con unbound ilue body.
ad spao }
#' \iadesired outpu.only=TRUound to plasmakm}{n velocity
#' in desired output concentration unctiara}s used in pKmucsair}{MucuscThisirWhether or not the out}s used in pKv)
ex}{R), tlasmadesired output con unbound intrinsic clearanefd to }
#' \iadesired outpu.only=TRUous used in pKvMic
ex}{R), tlasmadesired output con unbound inth the ank y Correcefd to }
#' \iadesired outpu.only=TRUound to plasmakUrtFraUnt modeled blor to adjustter 9ledts tovention. (ose ab^0.75s}
eight, kgload_.dcokinyan,cokinyr Figoad_ d ii/mL}
eight, kgMA}{phosphoackag:wm adjbrations for not the out,n place of the old}
eight, kgmal.,o ineara. bl.ggoad_}{n l.,o sclearan blogdy W Figoad_ wever, und to plasmaMic Moleonarrrance, uLi/molous used in ppKa_Aatist}{pes)
  AH \it@pa outpuon ts noiumel.
  Re(s)us used in ppKa_Donor}{pes)
  AH brat@pa outpuon ts nirumel.
  Re(s)us used in pPow}{oc  Rol:wm adjcolumns: "DSSTox_Substnce acedternserized)us used in ptilaFraUnt modelan rate is not known be mo(ose ab^0.75s}
eight, kgQcarerccFraCarercclasma
 dose absor^3/4 und to plasmaQgfrFraGlomernarrrFiled outpuRaV  dose absor^0.75,}{Hepatic iflui\s usept "3ch et al.port(l o.humacing C und to plasmaQgutfFunbound.plasmaarercclal indif intrin of thigutous used in pQport(lfFunbound.plasmaarercclal indif intrin of thiport(lsous used in pQgoad_fFunbound.plasmaarercclal indif intrin of thiload_.us used in pQgue fFunbound.plasmaarercclal indif intrin oflue body.
.us used in pQnth fFunbound.plasmnsic csamplnd_inh the ank us used in pChanges in vessay ur), tlasmd VDdesired output cr DTXSIDs
#'ce, uLmeter,sic cThid VDdesired outpuce, uL/ in version:when available
  well-.us used in pVartFraVHepatic i uL/arter helpadjabsank you Tom ML absorbes used in pVgutFraVHepatic i uL/ion padjabsank you Tom ML absorbes used in pVport(lFraVHepatic i uL/port(ls padjabsank you Tom ML absorbes used in pVload_FraVHepatic i uL/goad_ padjabsank you Tom ML absorbes used in pVlue FraVHepatic i uL/guepatpadjabsank you Tom ML absorbes used in pnten}{n velocity
#' intratium units. 
#' @para (1 heps}
eight, kgVmucFraUnt modelmucosimulating
# absor^0.75}
eight, kgVinh Fra VHepatic i uL/ith the default  padjabsank you Tom ML absorbes used in pVs nFraVHepatic i uL/veatapadjabsank you Tom ML absorbend toint}{Haun pl Mattn of a H,provided for 6,on 1ci/kfv118)d toint}{Hp default.tint}{ of a H,pMatthew Wuronal networon Model for Organic Chemicals"
  New chemicaint}{l specific parameters for volatile chems have a lod toint}{ction o, P. JuroGidez,pMuroHom{Fded J. B.mtablemodter, Aions/mal unb.o cleaolearnarrrtion tos enarugs:ew partitionpulati
#' \iper 95th)f-maximthank you Xincub small Funboule rosoion tion tos rnarugpackophts para 
  ThisximDrugpMFgutabs}{mtablDnk you Jame36(7), 1194-7, 1 assay adjus08.020834.d toint}{Hkeywovalees the pad toint}{Hman bug: as Whet 
#' @p<- ort(parameterize_schm(st be
#='129-00-0ude.{Clint}{het 
#' @p<- ort(parameterize_schm(st betiss='pyfaue',, "Mous='RaVude.{Clint}{het 
#' eterize_schm(st be
# = '56-23-5ude.{Clint}{het 
#' @p<- ort(parameterize_schm(st betiss='Carb1 theter hlon st',, "Mous='RaVude.{Clint}{#hemical not using tk onpouns usead

  This p<- .
#(load_=c("load_"),rtme=c("hfort","acein","t(solv","port(l"),s useeeeeeeeeeeeeeeeeeeeeeeguep=c("luep"),ion=c("ion"),samp=c("b1 e"))int}{het 
#' eterize_schm(st betiss="Bnk heRol a",, "Mous=").
#ank you Jason Phillip,s useeeeeeeeeeeeeeeeeeeeupings.
#=ad

  This )r the CAS nuhttkpo{het 
#' eterize_schm
het 
#' eterize_schmp<-  Either (st be
#=NULL, Chmeicaaaaaaaaaaaaaaaaaaaaaaaaast betiss=NULL, Chmeicaaaaaaaaaaaaaaaaaaaaaaaaa.epa.g=NULL, Chmeicaaaaaaaaaaaaaaaaaaaaaaaaa, "Mous="ng ani, Chmeicaaaaaaaaaaaaaaaaaaaaaaaaa.nk you Jason PhiF, Chmeicaaaaaaaaaaaaaaaaaaaaaaaaaupings.
#=.
#( Chmeicaaaaaaaaaaaaaaaaaaaaaaaaa  load_=c("load_"), Chmeicaaaaaaaaaaaaaaaaaaaaaaaaa  port(l=c("port(l"),s hmeicaaaaaaaaaaaaaaaaaaaaaaaaa  luep=c("luep"),s hmeicaaaaaaaaaaaaaaaaaaaaaaaaa  ion=c("ion")),s hmeicaaaaaaaaaaaaaaaaaaaaaaaaaepatic
#' intrinsic c= F, Chmeicaaaaaaaaaaaaaaaaaaaaaaaaa where the in
#' vitr=ove , Chmeicaaaaaaaaaaaaaaaaaaaaaaaaasma when set to
#' TRUE=T, ChmeicaaaaaaaaaaaaaaaaaaaaaaaaaSE for otheT, Chmeicaaaaaaaaaaaaaaaaaaaaaaaaanten = 0, Chmeicaaaaaaaaaaaaaaaaaaaaaaaaakm = 1, Chmeicaaaaaaaaaaaaaaaaaaaaaaaaaxercise-i= F, ChmeicaaaaaaaaaaaaaaaaaaaaaaaaafR = 12, ChmeicaaaaaaaaaaaaaaaaaaaaaaaaaVT = 0.75, ChmeicaaaaaaaaaaaaaaaaaaaaaaaaaVD = 0.15, Chmeicaaaaaaaaaaaaaaaaaaaaaaaaa suppressed.
#' iF, Chmeicaaaaaaaaaaaaaaaaaaaaaaaaa Monte Carlo coefficient et)., Chmeicaaaaaaaaaaaaaaaaaaaaaaaaa...)in{nt
 ults to direct <- oults to direct    #ranparamtocytema.discr DTXSIDs
#'he stan rate
nd cg pays rnion) 
stateif (is.null(st be
#) &ility iis.null(st betiss) &ility iis.null(.epa.g))ility ints ('st betiss,ust be
#r "Ra.epa.go @param D (\url{ht')    #rLitioninied. 
#' @param /ed (ede Softwarn sothereforlating statessag<- hanged t_id( Chmeist be
#=st be
#r Chmeist betiss=st betiss, Chmei.epa.g=.epa.g)d as a fu
# <- ssa$ a fu
#d as a furam d<- ssa$ a furam ddddddddddddddddddddddddddddddddearanepa.go<- ssa$nepa.gThis veteif (, exc(upings.
#)!='.
#')ints ("upings.
#' @param aiable allwarning.")ility#w used)are molpkgeshof hepatic intrinues (as b.dbo<- try(hang2016)
PK/or pa("(as b",, "Mous,st be
#=st be
#),si
   =T)lity#w heckthan 0not ufauy works wCLing aitem{d valtesting an:ues (as b.anged (<- try(hang2016)
PK/or pa("(as b.anged ",, "Mous,st be
#=st be
#),si
   =T)lityif ((, exc((as b.db) = biory- over" &i.nk you Jason Ph) ||aepatic
#' intrinsic )ility{ Chmei(as b.dbo<- try(hang2016)
PK/or pa("(as b","ng ani,st be
#=st be
#),si
   =T)litys (as b.anged (<- try(hang2016)
PK/or pa("(as b.anged ","ng ani,st be
#=st be
#),si
   =T)litys if (! suppressed.
#' ) Chmeicaop=F.
(ptmen(, "Mous,"speciemtocyng ane optiFgutabs, p value)} 
  Th"))in  }veteif (, exc((as b.db) = biory- over")ility ints ("Mpatic iiFgutabs, p value)} 
  Tent choadhen defauictioth human values
#Thidrreceffs if true fraction of h")lity#w hecktff w(really aarting reporteges brations for,tff s brations for,ticients.{Percestateif (necte((as b.db) - necte(gs i(",","",(as b.db))==3)ility{ Chmei(as b.dble <- (as b.db Chmei(as b<- as.nud by (atisplit((as b.db,",")[[1]][1])litys (as b.anged (<- as.nud by (atisplit((as b.db,",")[[1]][4])litys if (! suppressed.
#' )aop=F.
("(as blly lating ino zerult case wher")lity} elcie{ Chmei(as b <- (as b.db Chmei(as b.dble <- NAin  }veteif (!is.na((as b.anged ) &i(as b.anged (vised get_cheminfo behav)i(as b  <- 0d arti  #rThe Schents.PCmbaugh et ody.
#' Howot using rmatting wistate0)
  Neas no i<- ort(parametermodel frst be
#=st be
#r Chmeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii, "Mous=, "Mous, Chmeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii.nk you Jason Phi.nk you Jason Ph, Chmeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiieutral lipid vp=epatic
#' intrinsic r Chmeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii,suppressed.
#' iTr Chmeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii Monte Carlo coefficient Monte Carlo coefficien)lityPCmb<- oissues needed for a model frhet 
#' @=0)
  Neas no r Chmeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii, "Mous=, "Mous, Chmeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiisma when set to
#' TRUE=sma when set to
#' TRUE, ChmeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiSE for otheSE for othr Chmeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii,suppressed.
#' i,suppressed.
#' r Chmeiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii Monte Carlo coefficient Monte Carlo coefficien)li# Game  only_ody.
#'rlong witiable int.fup Fk only PCm,}{Hecalculasampsstate  only_as no i<-   on_ody.
#(PCm,upings.
#=upings.
#,, "Mous=, "Mous)arti  #r heckthoemicaif wm Dhlve ficients.ano 2016,hemicitem{w partitio:s veteif (Sipes et al. (2017) is nolity{ Chmeihemi<- 0)
  Neas no $al. (2017) is nlitys if (! suppressed.
#' )aop=F.
(
' are set 
#' eqitem{Funbfnte Ca 2016,ference in pr( for 6,o. "Idictiotsma when set to
#' TRUE rected (tefficieoriginnsic cle.')lity} elciehemi<- 0)
  Neas no $unsma when set to
#' TRUE    #rRta fromlected sinls, resstateif (hemi<i Monte Carlo coefficien)ehemi<-  Monte Carlo coefficient was c1.7 (Ju<- try(hang2016)
PK/or pa("c1.7 (J",, "Mous,st be
#=st be
#),si
   =T)lityif (, exc(unused i = biory- over")ic1.7 (Ju<- 1arti  y#w hecktha "info" foitterionsse pulpncel and Cl determinecularession) and ady miss Howot ug wiss veteif (!(, "Mous %in%r "Stissu(oults to direct))olity{ Chmeiif (toed bl(, "Mous) %in%rtoed bl( "Stissu(oults to direct))olityty{ Chmei
 ult., "Mous <-  "Stissu(oults to direct)[toed bl( "Stissu(oults to direct))==toed bl(, "Mous)] Chmei} elcients (ptmen("PHealth and NuPK 
  Tent ",, "Mous,0" raf coef"))in  } elcie ult., "Mous <- , "Mous    #rLia
  Update decrease package sizd corris , "Mous   f the  ult.rect <- oults to direct[, ult., "Mous] Chmtissu( the  ult.rect) <- oults to direct[,1]arti  y  ht<- hang CAS and/or pa("MWi,st be
#=st be
#) #i/mol by a s_Donor <- ,suppresW

  U(hang CAS and/or pa("a s_Donori,st be
#=st be
#)) # ac.gobrat@pa outpul.
  Res by a s_Aatist <- ,suppresW

  U(hang CAS and/or pa("a s_Aatisti,st be
#=st be
#)) # bath, aat@pa outpul.sn  Res by Powu<- 10^hang CAS and/or pa("ced i,st be
#=st be
#) # Oc  Rol:wm adjcolumns: "DSSToxe_Subst was outlble <- .
#(olityt# Beginasampsstate#mf hepakgBW_analytic_css ose abBWstateQGFRcu<- tthe  ult.rect["GFR"]/1000*60i  y QcarerccF = tthe  ult.rect["Carercclasma
"]/1000*60i  y afR thr Ch5nse aund plasma if \'5 Chmtise aund plasm),1,1sed i'Q'])Subst was outlblec(was out,ct_id( C  y Qcarercc(<- as.nud   y Qcareon")),s   y a[! Chmti  y aMous) %c('Qamete.n pQgo')], #MWLerwrite 0'in pQg', 9/19/19_id( C n pQgo=   y a[['Qamete.n pQgo']].db  y a[['QsmaQ']]n")),s asmaQrcc(<- as.nud  ateQ))ng.")iliecalculas1]arti.")iliyt# Besimulas.")iliare mo wm DhlbeTom Mpaki.")iin pVrccF = tthe  ult.reP
#' TnFraVHma(1-F = tthe  ult.reH kg.} 
#"])/2
"]/ #om Mpa.")iin pVrccF = tthe  ult.reP
#' TnFraVHma(1-F = tthe  ult.reH kg.} 
#"])/2
"]/ #om Mpa."bst was outlblec(was out,")),s in pVrcc(<- as.nud in pVon")),s in pVrcc(<- as.nud in pVon")),s se aund plasma if \'5 Chmtise aund plasm),1,1sed i'V']n")),s se aund plasma if \'5 Chmtise aund plasm),1,1sed i'K'])arti.")iarti  @partic i uaiablease packagabBWsBWGFRcu<- tthe  ult.reAlitygesBW"]r to tounts in ccF = tthe  ult.reH kg.} 
#"]bst was outlblec(was out, Ch5nBWGcc(<- as.nud BWon")),s sion 1.7=
  T, # ch,er")ilihen set to
#' T=ien),iliare lue (' \iper r")ilihen set to
#' as b.d=mi<- 0)
  Neas no $al. (2017) as b.n")),s  tounts in cc(<- as.nud  tounts in),iliare lue (sired")),s MWGccMW,
#) #i/moles by =s byn")),s pa("a s_D=pa("a s_Dn")),s pa("a s_Aa=pa("a s_Aan")),s MA#' @=0)
  Neas[["MA"]]n")),s asmakaafR1.0,
RbloodMWLe9-20-19_id( C, kgVaaVD nt ee
#RbloodMWLe9-20-19_id( h")lit causintionpulati
#' \iper 9utput con unbouic iaximthank youf true.
#' @param emici({Fraction of cor 60 from was outlblec(was out, Ch5nr")ilihound in hepatocyte
=y
  Fixefu.
#( Chmase package=e <- . by =si<- 0)
  Neas  byn")),s s pa("a s_D=i<- 0)
  Neas pa("a s_Dn")),s s pa("a s_Aa=i<- 0)
  Neas pa("a s_Aan")),s iiiiii,suppressed.
#' i,suppressed.)))ng)li' \iper 9."bst hmeiaaaa==0ct))olity{ Chmeiif (! suppressed.
##' ) Chmeicaop=Fectnl)
 g a tissuss foogy.ditem{Fgutaor calcaaanten fup.measf intri time-ctiene optiFgutabs, p val wher")m was outlblec(was out, 
#=.
#( Chmaaaa=n = 0, Chmkm=1,
kmlected sin1(realldummylected  p-v= 0, Chmav)i(=av)i(, = 0, Chmav)i(as b.d=mav)i(as b.,= 0, Chmavitem{Fgutab cc(<- as.nud y
  Fixed output .
#( Chmeissa$ a fur= iss=st betiss, C),s  the modnamin="uFraUnt g ani, Chmeil frhet 
#
#=.
#( Chmeicaav)i(=av)i(, #geshof hepatic intrinnnnnnnnnte Carlo coefficen),iliare lue (' \iper r")ili C),s  thd in hepatocyte
=was out$hound in hepatocyte
, = 0, Chmiiiiiikgmal.,o ineara. bl.ggafR10, # cepatic in/g-bl.gg= 0, Chmiiii, kgload_.dcoafRtr=o #  d i= 0, ChmiiiiDn=0.17,BW=BW
#' r Chmeiiiin pVlo=se aund plasm$in pVlo, #om M#' r ChmeiiiQamete.n pQgc=ise aund plasm$Qamete.n pQgc)
"]/100on")),s hmeiiiii,suppressed.
#)), #om dose a")),s hmiikgmal.,o ineara. bl.ggaR10, # cepatic in/g-bl.gg= 0, Chm, kgload_.dcoaRtr=o #  d i= 0, Chmr")ic1.=exc(unus) #om dose a")),lity} elcie{ Cwas outlblec(was out, Ch5nr")ilihmaaaa=aaaa,km=km,= 0, Chmav)i(=av)i(, = 0, Chmav)i(as b.d=mav)i(as b., = 0, Chmavitem{Fgutab=n ddddddddddddddddddddddddddds hmiikgmal.,o ineara. bl.ggaR10, # cepatic in/g-bl.gg= 0, Chm, kgload_.dcoaRtr=o #  d i= 0, Chmr")ic1.=exc(unus)#ML.physicKaaakkml9-19-19_id(in  n  n  veteif (Sipes et al. (2017) i==3)ility{ Cwas out["asma adjusted as
#' descr"]ihemi<- 0)
  Neas no $al. (2017) s
#' descr")),lity} ewas out["asma adjusted as
#' descr"]ihem <- NA cie{ Cwas outlblec(was out,= 0, Chmin pChanges i=ion:when available
  wel frst be
#=st be
#r Chmeiiiii, "Mous=, "Mous, Chmeiiiiisma when set to
#' TRUE=sma when set to
#' TRUE, Chmeiiiii,suppressed.
#))RUE, CRUE, C#odelan rate is not k: 15_css os^.75d for prmpbed tunboRUE, C#henry's la Piroatm * m^3 /  #i,kgBW_analytatm triPaRUE, C#hre frohe anvalues for sin310 Kelvi r")ilipa(Henryaak 10^hang CAS and/orBW}{Bo i'pa(Henry', d i,st be
#=st be
tionce ard an10 
#=int mHenry's la Pe)} 
#'),s  l Powu<-pa(Henrya#Henry's utpul.
Piroatm*m^3 /  #iCRUE, C#Gas utpul.
P8.314Piroare molpkJ/( #i*K),rohe anvalues for RUE, Cohe _nval cc(<- as.nud F = tthe  ult.r'AlitygesBhe aTvalues for']) + 273.15_#C -> KRUE, CKRol:wKmuc Pow8.314P*Cohe _nval / ( l *wu<1325 CAS#u<1325tatm triPa RUE, Cin pKhange PowKRol:wKmuc *Cwas out$

Changes in/Cwas out$no $al. (2017) is nlilKmuc2 kglble og10(1/KRol:wKmucb.db( og10(Peolaowu) *C0.524 #IfdeteShyam Patload imagepa(", it'spKa data in pKmuc ccKRol:wKmucRUE, Cimuc2 kglbleu<-(lKmuc2 kg)RUE, Cin pKmuc bleu/Kmuc2 kgity{ Chm(aaaaxerc)tyty{ Chmin pt cc((fR100o *C(VTaowVD))/was out$ absor^ #om dosbsor^0.yty{ Chm#Rblood4-30-19ation as an op-rs nee blor to adj 
Chan for e)} 
TRUE, Chm#Ka datsers neeare molpkLty andin^-1us)] Chmei} etyty{ ChmVdotGFRcu<- tthe  ult.reP VT TidalVe is not knutpu"]yty{ Chmin pt FRcVdotG*C(0.67) #om dosbsor^us)] Chcie{ Cwas outlblec(was out,in pKhange = Cin pKhange,in pKmuc ccKn pKmuc,in pt=(<- as.nud  n pt))RUE, CRUE, CE, CRUE,
#'rl(lapply(was o