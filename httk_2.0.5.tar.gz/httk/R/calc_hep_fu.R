#' Calculate the free chemical  p_fu.R           =T,
        i earanceters Cheminot to suppress tr kg
#'Kilg cd ramalf the 8)al unbound in in instead     =T,
             int <- Clinance.
#' eters Cheminot to supprel Abstract Services Registry Number (CAS-RN) -- if
#'  parameters is not specified then the chemical must be identified by either
#'  CAS, name, or DTXISD
#' @param chem.name Chemical name (spaces and capitalization ignored) --  if
#'  parameters is not specified then the chemical must be identified by either
#'  CAS, name, or DTXISD
#' @param dtxsid EPA's 'DSSTox Structure ID (\url{https://comptox.epa.gov/dashboard})  
#'  -- if parameters is not specified then the chemical must be identified by 
#' either CAS, name, or DTXSIDs
#' @param parameters Parameters from the appropriate parameterization function
#' for the model indicated by argument model
#' @param restrictive.clearance PVr Rricti in v
  vrs owholeincubthe movrs ow. Df the lowe to
#ramethem.nWetmoely amalf the15)Parameters frHfrHfels forincupthe moint.um.table whose columnian valueound in betwep_cm.Fuored)oneambaugh and Robert Pearce
#'
#' @keywords Parameter
#lcolm, LesliKilg cd,ds d moJ04) amalf ulatedov
 kidneaccount els vits:e(chem.           by instead eound in    int <- Clinancubthe ms data flated heailable account ern vitrlipophilic    s are" DvitrMrst pass t#' @Dispos @para36.7lable the 8): 1194-1197 
#' calcWetmoel, Barbers A04) amalf uIn.  anc, unscaigh-(Rowlan welarantaselearance using ms on.
dos #' ry-a when serom hepat            oleine forlly available   ic    sea unse" T ico
#'@retuS.stiesli148.1 the15)word1 physiology 
#'
#' @imin- hepa
#'                       learance
calc_hep_clefu    lear function(cfu                 chem.cas=NULL,                        dtxsid =                          chem.cas=                        parameter                          species='Vr.list         minimum.FunbpH=7.4orree the chemical to be simulated one way or another:
  if (is.null(chem.cas) & 
      is.null(chem.name) & 
      is.null(dtxsid) &
      is.null(parameters)) 
    stop('Parameters, chem.name, chem.cas, or dtxsid must be specified.')

  if (is.null(parameters))
  {
    parameters <- parameterize_pbtk(
                    chem.cas=chem.cas,
                    chem.name=chem.name,
                    dtxsid=dtxsid)
  }
  
  if (!all(c("Qtotal.liverc","FunbounPowersiKa_DometersiKa_Accs."ameters))) 
    stop("Missing needed parameters in caize_pbtk(
lc_hepalability.")    _pre<- out$dtxsid
 density <- get_paPowlasma
      } Powt_paiKa_Dometlasma
      } iKa_Domett_paiKa_Accs."lasma
      } iKa_Accs."ters))
  {_base(pH=pH,aiKa_Domet=iKa_Domet,aiKa_Accs."=iKa_Accs." <- parameter
#'PDcalcula10m.namedowchem.cas=chem.cas,Pow,xsid
 density <- pH=pH,sid
 density <- pKa_Domet=iKa_Domet,sid
 density <- pKa_Accs."=iKa_Accs." <model) == "p
#'PDcalcula10mPowk_precisi          1/(1+ord5*Vr*10^(lis72*
#'PD^2+lis67*
#'PD-1.126 <- # V   o    d    cky orke          on.to ateads:cisi      [        0 |i      >1]erc <- get_paon(as.numeric(CL