## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## -----------------------------------------------------------------------------
library(data.table)
library(ggplot2)
devtools::load_all()

## -----------------------------------------------------------------------------
set.seed(42)

## -----------------------------------------------------------------------------
par <- as.data.table(expand.grid(gfr_resid_var = c(FALSE, TRUE),
                                 ckd_epi_race_coeff = c(TRUE, FALSE)))

DT <- par[,
          .(gfr_est=httkpop_generate(method = "d",
                                     nsamp = 1000,
                                     agelim_years = c(18,65),
                                     reths = "Non-Hispanic Black",
                                     gfr_resid_var = gfr_resid_var,
                                     ckd_epi_race_coeff = ckd_epi_race_coeff)$gfr_est),
          by = .(gfr_resid_var,
                 ckd_epi_race_coeff)]

DT[, label:=paste("resid",
                                           gfr_resid_var,
                                                 "coeff",
                                           ckd_epi_race_coeff,
                                           sep = "_")]

## -----------------------------------------------------------------------------

ggplot(DT) +geom_density(aes(x=gfr_est,
                             color = label,
                             fill = label),
                             alpha = 0.2,
                         size=1) +
  scale_color_brewer(palette = "Set2") +
  scale_fill_brewer(palette = "Set2")


## -----------------------------------------------------------------------------
css_bpa <- par[, .(css=calc_mc_css(chem.name = "bisphenol A",
                                 samples = 1000,
                                 return.samples = TRUE,
                                 output.units = "uM",
                                 httkpop.generate.arg.list = list("gfr_resid_var" = gfr_resid_var, "ckd_epi_race_coeff" = ckd_epi_race_coeff))),
    by = .(gfr_resid_var, ckd_epi_race_coeff)]


## -----------------------------------------------------------------------------
css_bpa[, label:=paste("resid",
                                           gfr_resid_var,
                                                 "coeff",
                                           ckd_epi_race_coeff,
                                           sep = "_")]
ggplot(css_bpa,
       aes(x=css, color = label, fill = label)) +
  geom_density(size=1,
               alpha=0.2) +
  scale_color_brewer(palette="Set2") +
  scale_fill_brewer(palette="Set2") +
  scale_x_log10() +
  xlab("Css, uM") +
  ylab("Density") +
  ggtitle("Css density for Bisphenol A")

## -----------------------------------------------------------------------------
ggplot(css_bpa,
       aes(x=css, color = label, fill = label)) +
  stat_ecdf() +
  scale_color_brewer(palette="Set2") +
  scale_fill_brewer(palette="Set2") +
  scale_x_log10() +
  xlab("Css, uM") +
  ylab("Cumulative density") +
  ggtitle("Css CDF for Bisphenol A")

## -----------------------------------------------------------------------------
aed_bpa <- par[, as.list(calc_mc_oral_equiv(chem.name = "bisphenol A",
                                            conc = 1,
                                 samples = 1000,
                                 which.quantile = c(0.05,0.5,0.95),
                                 httkpop.generate.arg.list = list("gfr_resid_var" = gfr_resid_var, "ckd_epi_race_coeff" = ckd_epi_race_coeff))),
    by = .(gfr_resid_var, ckd_epi_race_coeff)]

knitr::kable(aed_bpa)

